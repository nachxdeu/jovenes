import { env } from "cloudflare:workers";
import { requireInternalProfile } from "../../../../lib/session";

export const dynamic = "force-dynamic";

export async function GET(
  _request: Request,
  context: { params: Promise<{ key: string[] }> },
) {
  await requireInternalProfile("/documentos");
  const params = await context.params;
  const key = params.key.join("/");
  const object = await env.FILES.get(key);

  if (!object) {
    return new Response("Archivo no encontrado", { status: 404 });
  }

  const headers = new Headers();
  object.writeHttpMetadata(headers);
  headers.set("etag", object.httpEtag);
  headers.set("cache-control", "private, max-age=120");
  headers.set("content-disposition", `inline; filename="${safeName(key)}"`);

  return new Response(object.body, { headers });
}

function safeName(key: string) {
  return key.split("/").at(-1)?.replace(/"/g, "") || "adjunto";
}
