import Link from "next/link";
import { AppShell } from "../components/app-shell";
import {
  ActivityCard,
  ArgumentCardView,
  DocumentCard,
  EmptyState,
  EventCard,
  MinuteCard,
  PageHeader,
  Panel,
  QuickLink,
  SectionTitle,
  TaskList,
} from "../components/ui";
import { coordinators } from "../lib/catalog";
import { getDashboardData } from "../lib/repository";
import { requireInternalProfile } from "../lib/session";

export const dynamic = "force-dynamic";

export default async function Home() {
  const profile = await requireInternalProfile("/");
  const data = await getDashboardData();

  return (
    <AppShell current="/" profile={profile}>
      <PageHeader eyebrow="Espacio privado" title="Organización, archivo y memoria interna">
        <div className="grid grid-cols-2 gap-2 text-center sm:grid-cols-4">
          <Stat label="Eventos" value={data.events.length} />
          <Stat label="Fichas" value={data.argumentCards.length} />
          <Stat label="Docs" value={data.documents.length} />
          <Stat label="Tareas" value={data.tasks.length} />
        </div>
      </PageHeader>

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-5">
        {coordinators.map((coordinator) => (
          <QuickLink
            accent={coordinator.accent}
            href={`/coordinadoras/${coordinator.slug}`}
            key={coordinator.slug}
            text={coordinator.description}
            title={coordinator.name}
          />
        ))}
      </section>

      <section className="grid gap-5 xl:grid-cols-[1.2fr_0.8fr]">
        <Panel>
          <SectionTitle
            action={<ModuleLink href="/calendario">Ver calendario</ModuleLink>}
            title="Próximos eventos"
          />
          <div className="mt-4 grid gap-3">
            {data.events.length ? (
              data.events.map((event) => (
                <EventCard event={event} key={event.id} profile={profile} />
              ))
            ) : (
              <EmptyState>No hay eventos próximos.</EmptyState>
            )}
          </div>
        </Panel>

        <Panel>
          <SectionTitle title="Acuerdos pendientes" />
          <div className="mt-3">
            <TaskList profile={profile} tasks={data.tasks} />
          </div>
        </Panel>
      </section>

      <section className="grid gap-5 xl:grid-cols-4">
        <Panel>
          <SectionTitle
            action={<ModuleLink href="/argumentario">Ver fichas</ModuleLink>}
            title="Argumentario reciente"
          />
          <div className="mt-4 grid gap-3">
            {data.argumentCards.length ? (
              data.argumentCards.map((card) => (
                <ArgumentCardView card={card} key={card.id} profile={profile} />
              ))
            ) : (
              <EmptyState>No hay fichas de argumentario.</EmptyState>
            )}
          </div>
        </Panel>

        <Panel>
          <SectionTitle
            action={<ModuleLink href="/documentos">Ver documentos</ModuleLink>}
            title="Últimos documentos"
          />
          <div className="mt-4 grid gap-3">
            {data.documents.length ? (
              data.documents.map((document) => (
                <DocumentCard
                  document={document}
                  key={document.id}
                  profile={profile}
                />
              ))
            ) : (
              <EmptyState>No hay documentos registrados.</EmptyState>
            )}
          </div>
        </Panel>

        <Panel>
          <SectionTitle action={<ModuleLink href="/actas">Ver actas</ModuleLink>} title="Últimas actas" />
          <div className="mt-4 grid gap-3">
            {data.minutes.length ? (
              data.minutes.map((minute) => (
                <MinuteCard key={minute.id} minute={minute} profile={profile} />
              ))
            ) : (
              <EmptyState>No hay actas publicadas.</EmptyState>
            )}
          </div>
        </Panel>

        <Panel>
          <SectionTitle
            action={<ModuleLink href="/memoria">Ver memoria</ModuleLink>}
            title="Memoria reciente"
          />
          <div className="mt-4 grid gap-3">
            {data.activities.length ? (
              data.activities.map((activity) => (
                <ActivityCard
                  activity={activity}
                  key={activity.id}
                  profile={profile}
                />
              ))
            ) : (
              <EmptyState>No hay actividades en la memoria.</EmptyState>
            )}
          </div>
        </Panel>
      </section>
    </AppShell>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-md border border-white/70 bg-white/80 px-3 py-2">
      <p className="text-xl font-black text-[var(--primary-dark)]">{value}</p>
      <p className="text-[11px] font-black uppercase text-zinc-500">{label}</p>
    </div>
  );
}

function ModuleLink({ children, href }: { children: React.ReactNode; href: string }) {
  return (
    <Link
      className="focus-ring rounded-md border border-zinc-300 px-3 py-2 text-xs font-black text-zinc-800 hover:bg-zinc-50"
      href={href}
    >
      {children}
    </Link>
  );
}
