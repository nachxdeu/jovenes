import Link from "next/link";
import { AppShell } from "../../components/app-shell";
import { ArgumentCardForm } from "../../components/forms";
import {
  ArgumentCardView,
  EmptyState,
  PageHeader,
  Panel,
  SectionTitle,
} from "../../components/ui";
import { argumentCardTypes, coordinators } from "../../lib/catalog";
import {
  distinctArgumentCampaigns,
  distinctArgumentTerritories,
  distinctArgumentTopics,
  listArgumentCards,
} from "../../lib/repository";
import { requireInternalProfile } from "../../lib/session";
import type { ArgumentCard } from "../../lib/types";

export const dynamic = "force-dynamic";

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

export default async function ArgumentarioPage({
  searchParams,
}: {
  searchParams: SearchParams;
}) {
  const params = await searchParams;
  const profile = await requireInternalProfile("/argumentario");
  const groupBy = first(params.agrupar) === "territorio" ? "territorio" : "tema";
  const filters = {
    search: first(params.q),
    topic: first(params.tema),
    territory: first(params.territorio),
    type: first(params.tipo),
    coordinator: first(params.coordinadora),
    campaign: first(params.campana),
  };
  const [cards, topics, territories, campaigns] = await Promise.all([
    listArgumentCards(filters),
    distinctArgumentTopics(),
    distinctArgumentTerritories(),
    distinctArgumentCampaigns(),
  ]);
  const grouped = groupArgumentCards(cards, groupBy);

  return (
    <AppShell current="/argumentario" profile={profile}>
      <PageHeader
        eyebrow="Fichas políticas"
        title="Argumentario"
      >
        <p className="max-w-md text-sm font-semibold leading-6 text-zinc-700">
          Fichas agrupadas por temáticas, territorios, campañas y mensajes para
          intervenir con criterio común.
        </p>
      </PageHeader>

      <section className="grid gap-5 xl:grid-cols-[0.95fr_1.35fr]">
        <Panel>
          <SectionTitle title="Nueva ficha" />
          <div className="mt-4">
            <ArgumentCardForm profile={profile} />
          </div>
        </Panel>

        <Panel>
          <SectionTitle title="Buscar y agrupar" />
          <form className="mt-4 grid gap-3" method="get">
            <input
              className="focus-ring min-h-11 rounded-md border border-zinc-300 px-3 py-2 text-sm font-medium"
              defaultValue={filters.search}
              name="q"
              placeholder="Buscar por título, mensaje, dato o etiqueta"
            />
            <div className="grid gap-3 md:grid-cols-3">
              <select
                className="focus-ring min-h-11 rounded-md border border-zinc-300 px-3 py-2 text-sm font-bold"
                defaultValue={filters.topic}
                name="tema"
              >
                <option value="">Todas las temáticas</option>
                {topics.map((topic) => (
                  <option key={topic} value={topic}>
                    {topic}
                  </option>
                ))}
              </select>
              <select
                className="focus-ring min-h-11 rounded-md border border-zinc-300 px-3 py-2 text-sm font-bold"
                defaultValue={filters.territory}
                name="territorio"
              >
                <option value="">Todos los territorios</option>
                {territories.map((territory) => (
                  <option key={territory} value={territory}>
                    {territory}
                  </option>
                ))}
              </select>
              <select
                className="focus-ring min-h-11 rounded-md border border-zinc-300 px-3 py-2 text-sm font-bold"
                defaultValue={filters.type}
                name="tipo"
              >
                <option value="">Todos los tipos</option>
                {argumentCardTypes.map((type) => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </select>
            </div>
            <div className="grid gap-3 md:grid-cols-3">
              <select
                className="focus-ring min-h-11 rounded-md border border-zinc-300 px-3 py-2 text-sm font-bold"
                defaultValue={filters.coordinator}
                name="coordinadora"
              >
                <option value="">Todas las coordinadoras</option>
                {coordinators.map((coordinator) => (
                  <option key={coordinator.slug} value={coordinator.slug}>
                    {coordinator.name}
                  </option>
                ))}
              </select>
              <select
                className="focus-ring min-h-11 rounded-md border border-zinc-300 px-3 py-2 text-sm font-bold"
                defaultValue={filters.campaign}
                name="campana"
              >
                <option value="">Todas las campañas</option>
                {campaigns.map((campaign) => (
                  <option key={campaign} value={campaign}>
                    {campaign}
                  </option>
                ))}
              </select>
              <select
                className="focus-ring min-h-11 rounded-md border border-zinc-300 px-3 py-2 text-sm font-bold"
                defaultValue={groupBy}
                name="agrupar"
              >
                <option value="tema">Agrupar por temática</option>
                <option value="territorio">Agrupar por territorio</option>
              </select>
            </div>
            <div className="flex flex-wrap gap-2">
              <button className="focus-ring rounded-md bg-[var(--primary)] px-4 py-2 text-sm font-black text-white">
                Filtrar
              </button>
              <Link
                className="focus-ring rounded-md border border-zinc-300 px-4 py-2 text-sm font-black text-zinc-800"
                href="/argumentario"
              >
                Limpiar
              </Link>
              <Link
                className="focus-ring rounded-md border border-zinc-300 px-4 py-2 text-sm font-black text-zinc-800"
                href={groupHref(params, groupBy === "tema" ? "territorio" : "tema")}
              >
                Ver por {groupBy === "tema" ? "territorio" : "temática"}
              </Link>
            </div>
          </form>

          <div className="mt-5 grid gap-5">
            {grouped.length ? (
              grouped.map((group) => (
                <section className="grid gap-3" key={group.label}>
                  <div className="flex items-center justify-between gap-3 border-b border-[var(--line)] pb-2">
                    <h2 className="text-lg font-black">{group.label}</h2>
                    <span className="rounded-full bg-zinc-100 px-2.5 py-1 text-xs font-black text-zinc-700">
                      {group.cards.length} fichas
                    </span>
                  </div>
                  {group.cards.map((card) => (
                    <ArgumentCardView
                      card={card}
                      key={card.id}
                      profile={profile}
                    />
                  ))}
                </section>
              ))
            ) : (
              <EmptyState>No hay fichas con esos filtros.</EmptyState>
            )}
          </div>
        </Panel>
      </section>
    </AppShell>
  );
}

function groupArgumentCards(cards: ArgumentCard[], groupBy: "tema" | "territorio") {
  const groups = new Map<string, ArgumentCard[]>();
  for (const card of cards) {
    const label = groupBy === "tema" ? card.topic : card.territory;
    const key = label || "Sin clasificar";
    groups.set(key, [...(groups.get(key) ?? []), card]);
  }
  return [...groups.entries()].map(([label, groupCards]) => ({
    label,
    cards: groupCards,
  }));
}

function groupHref(
  params: Record<string, string | string[] | undefined>,
  groupBy: "tema" | "territorio",
) {
  const next = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (!value) continue;
    next.set(key, Array.isArray(value) ? value[0] ?? "" : value);
  }
  next.set("agrupar", groupBy);
  return `/argumentario?${next.toString()}`;
}

function first(value: string | string[] | undefined) {
  return Array.isArray(value) ? value[0] ?? "" : value ?? "";
}
