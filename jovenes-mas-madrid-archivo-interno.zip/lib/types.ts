export type Role = "admin" | "coordinator" | "internal";

export type CoordinatorSlug =
  | "comunicacion"
  | "ideologia"
  | "estrategia"
  | "logistica"
  | "agitprop";

export type Coordinator = {
  slug: CoordinatorSlug;
  name: string;
  accent: string;
  description: string;
};

export type UserProfile = {
  email: string;
  name: string;
  role: Role;
  coordinatorSlug: CoordinatorSlug | null;
};

export type DocumentType =
  | "acta"
  | "argumentario"
  | "campaña"
  | "informe"
  | "diseño"
  | "protocolo"
  | "calendario"
  | "otro";

export type EventType =
  | "reunión"
  | "acción de calle"
  | "formación"
  | "campaña"
  | "acto público"
  | "encuentro interno"
  | "otro";

export type ArgumentCardType =
  | "ficha"
  | "mensaje clave"
  | "dato"
  | "respuesta rápida"
  | "marco político"
  | "otro";

export type InternalDocument = {
  id: string;
  title: string;
  summary: string;
  coordinatorSlug: CoordinatorSlug;
  type: DocumentType;
  uploadedAt: string;
  owner: string;
  attachmentName: string;
  attachmentUrl: string;
  tags: string;
  createdByEmail: string;
  createdAt: string;
};

export type MeetingMinute = {
  id: string;
  title: string;
  meetingDate: string;
  spaceSlug: CoordinatorSlug | "general";
  attendees: string;
  agenda: string;
  agreements: string;
  assignedTasks: string;
  nextMeeting: string;
  attachmentUrl: string;
  body: string;
  createdByEmail: string;
  createdAt: string;
};

export type InternalEvent = {
  id: string;
  title: string;
  eventDate: string;
  eventTime: string;
  place: string;
  description: string;
  coordinatorSlug: CoordinatorSlug;
  type: EventType;
  people: string;
  resourceUrl: string;
  createdByEmail: string;
  createdAt: string;
};

export type Activity = {
  id: string;
  title: string;
  activityDate: string;
  year: number;
  place: string;
  description: string;
  coordinatorSlugs: CoordinatorSlug[];
  objective: string;
  materials: string;
  links: string;
  evaluation: string;
  tags: string;
  type: string;
  campaign: string;
  createdByEmail: string;
  createdAt: string;
};

export type CoordinatorTask = {
  id: string;
  coordinatorSlug: CoordinatorSlug;
  title: string;
  status: "pending" | "done";
  dueDate: string;
  source: string;
  createdByEmail: string;
  createdAt: string;
};

export type ArgumentCard = {
  id: string;
  title: string;
  summary: string;
  topic: string;
  territory: string;
  type: ArgumentCardType;
  coordinatorSlug: CoordinatorSlug;
  campaign: string;
  keyMessages: string;
  dataPoints: string;
  rebuttal: string;
  sources: string;
  tags: string;
  updatedAt: string;
  createdByEmail: string;
  createdAt: string;
};
