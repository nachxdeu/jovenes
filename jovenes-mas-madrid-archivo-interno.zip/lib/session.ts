import { chatGPTSignOutPath, getChatGPTUser, requireChatGPTUser } from "../app/chatgpt-auth";
import { getOrCreateProfile } from "./repository";
import type { CoordinatorSlug, UserProfile } from "./types";

export async function requireInternalProfile(returnTo = "/") {
  const chatUser =
    (await getChatGPTUser()) ??
    (process.env.NODE_ENV === "production"
      ? await requireChatGPTUser(returnTo)
      : {
          displayName: "Desarrollo local",
          email: "desarrollo@jovenesmasmadrid.local",
          fullName: "Desarrollo local",
        });

  return getOrCreateProfile({
    email: chatUser.email,
    name: chatUser.displayName,
  });
}

export function canManage(
  profile: UserProfile,
  coordinatorSlug?: CoordinatorSlug | "general" | null,
) {
  if (profile.role === "admin") return true;
  if (profile.role !== "coordinator") return false;
  if (!coordinatorSlug || coordinatorSlug === "general") return false;
  return profile.coordinatorSlug === coordinatorSlug;
}

export function canCreateFor(profile: UserProfile, coordinatorSlug: CoordinatorSlug) {
  return canManage(profile, coordinatorSlug);
}

export function roleLabel(role: UserProfile["role"]) {
  if (role === "admin") return "Administrador/a";
  if (role === "coordinator") return "Coordinador/a";
  return "Usuario/a interno";
}

export function signOutPath() {
  return chatGPTSignOutPath("/");
}
