import type {
  Coordinator,
  CoordinatorSlug,
  ArgumentCardType,
  DocumentType,
  EventType,
} from "./types";

export const coordinators: Coordinator[] = [
  {
    slug: "comunicacion",
    name: "Comunicación",
    accent: "#0f8f43",
    description:
      "Relato público, redes, prensa, argumentarios y coordinación de mensajes.",
  },
  {
    slug: "ideologia",
    name: "Ideología",
    accent: "#7057d5",
    description:
      "Formación, debate político, documentos marco y elaboración programática.",
  },
  {
    slug: "estrategia",
    name: "Estrategia",
    accent: "#0b68a8",
    description:
      "Planificación política, campañas, alianzas y lectura de coyuntura.",
  },
  {
    slug: "logistica",
    name: "Logística",
    accent: "#d2642a",
    description:
      "Recursos, espacios, materiales, turnos y soporte práctico a la actividad.",
  },
  {
    slug: "agitprop",
    name: "Agitprop",
    accent: "#d1265b",
    description:
      "Creatividad política, acciones de calle, pegadas, pancartas y materiales.",
  },
];

export const documentTypes: DocumentType[] = [
  "acta",
  "argumentario",
  "campaña",
  "informe",
  "diseño",
  "protocolo",
  "calendario",
  "otro",
];

export const eventTypes: EventType[] = [
  "reunión",
  "acción de calle",
  "formación",
  "campaña",
  "acto público",
  "encuentro interno",
  "otro",
];

export const activityTypes = [
  "acción de calle",
  "formación",
  "campaña",
  "acto público",
  "encuentro interno",
  "producción de materiales",
  "otro",
];

export const argumentCardTypes: ArgumentCardType[] = [
  "ficha",
  "mensaje clave",
  "dato",
  "respuesta rápida",
  "marco político",
  "otro",
];

export const defaultArgumentTopics = [
  "Vivienda",
  "Transporte",
  "Educación",
  "Empleo joven",
  "Feminismos",
  "Clima",
  "Cultura",
];

export const defaultTerritories = [
  "Madrid ciudad",
  "Norte",
  "Sur",
  "Este",
  "Oeste",
  "Universidades",
  "Regional",
];

export function getCoordinator(slug: string | null | undefined) {
  return coordinators.find((coordinator) => coordinator.slug === slug) ?? null;
}

export function isCoordinatorSlug(value: string): value is CoordinatorSlug {
  return coordinators.some((coordinator) => coordinator.slug === value);
}
