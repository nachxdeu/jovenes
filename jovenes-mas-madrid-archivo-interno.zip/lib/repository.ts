import { env } from "cloudflare:workers";
import { coordinators } from "./catalog";
import type {
  Activity,
  ArgumentCard,
  ArgumentCardType,
  CoordinatorSlug,
  CoordinatorTask,
  DocumentType,
  InternalDocument,
  InternalEvent,
  MeetingMinute,
  Role,
  UserProfile,
} from "./types";
import { normalizeSearch, todayIso, uid } from "./utils";

type BindValue = string | number | null;

let initialized = false;
let initializationPromise: Promise<void> | null = null;

function getBinding() {
  if (!env.DB) {
    throw new Error("No se ha encontrado la base de datos interna.");
  }
  return env.DB;
}

export async function ensureDatabase() {
  if (initialized) return;
  if (initializationPromise) {
    await initializationPromise;
    return;
  }

  initializationPromise = initializeDatabase().catch((error) => {
    initializationPromise = null;
    throw error;
  });
  await initializationPromise;
}

async function initializeDatabase() {
  if (initialized) return;

  const db = getBinding();
  await db.batch([
    db.prepare(
      `CREATE TABLE IF NOT EXISTS coordinators (
        slug TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        accent TEXT NOT NULL,
        description TEXT NOT NULL DEFAULT ''
      )`,
    ),
    db.prepare(
      `CREATE TABLE IF NOT EXISTS users (
        email TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'internal',
        coordinator_slug TEXT,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`,
    ),
    db.prepare(
      `CREATE TABLE IF NOT EXISTS documents (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        summary TEXT NOT NULL DEFAULT '',
        coordinator_slug TEXT NOT NULL,
        type TEXT NOT NULL,
        uploaded_at TEXT NOT NULL,
        owner TEXT NOT NULL,
        attachment_name TEXT NOT NULL DEFAULT '',
        attachment_url TEXT NOT NULL DEFAULT '',
        tags TEXT NOT NULL DEFAULT '',
        created_by_email TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`,
    ),
    db.prepare(
      `CREATE TABLE IF NOT EXISTS minutes (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        meeting_date TEXT NOT NULL,
        space_slug TEXT NOT NULL,
        attendees TEXT NOT NULL DEFAULT '',
        agenda TEXT NOT NULL DEFAULT '',
        agreements TEXT NOT NULL DEFAULT '',
        assigned_tasks TEXT NOT NULL DEFAULT '',
        next_meeting TEXT NOT NULL DEFAULT '',
        attachment_url TEXT NOT NULL DEFAULT '',
        body TEXT NOT NULL DEFAULT '',
        created_by_email TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`,
    ),
    db.prepare(
      `CREATE TABLE IF NOT EXISTS events (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        event_date TEXT NOT NULL,
        event_time TEXT NOT NULL DEFAULT '',
        place TEXT NOT NULL DEFAULT '',
        description TEXT NOT NULL DEFAULT '',
        coordinator_slug TEXT NOT NULL,
        type TEXT NOT NULL,
        people TEXT NOT NULL DEFAULT '',
        resource_url TEXT NOT NULL DEFAULT '',
        created_by_email TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`,
    ),
    db.prepare(
      `CREATE TABLE IF NOT EXISTS activities (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        activity_date TEXT NOT NULL,
        year INTEGER NOT NULL,
        place TEXT NOT NULL DEFAULT '',
        description TEXT NOT NULL DEFAULT '',
        coordinator_slugs TEXT NOT NULL DEFAULT '[]',
        objective TEXT NOT NULL DEFAULT '',
        materials TEXT NOT NULL DEFAULT '',
        links TEXT NOT NULL DEFAULT '',
        evaluation TEXT NOT NULL DEFAULT '',
        tags TEXT NOT NULL DEFAULT '',
        type TEXT NOT NULL DEFAULT 'otro',
        campaign TEXT NOT NULL DEFAULT '',
        created_by_email TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`,
    ),
    db.prepare(
      `CREATE TABLE IF NOT EXISTS tasks (
        id TEXT PRIMARY KEY,
        coordinator_slug TEXT NOT NULL,
        title TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        due_date TEXT NOT NULL DEFAULT '',
        source TEXT NOT NULL DEFAULT '',
        created_by_email TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`,
    ),
    db.prepare(
      `CREATE TABLE IF NOT EXISTS argument_cards (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        summary TEXT NOT NULL DEFAULT '',
        topic TEXT NOT NULL,
        territory TEXT NOT NULL DEFAULT 'General',
        type TEXT NOT NULL DEFAULT 'ficha',
        coordinator_slug TEXT NOT NULL,
        campaign TEXT NOT NULL DEFAULT '',
        key_messages TEXT NOT NULL DEFAULT '',
        data_points TEXT NOT NULL DEFAULT '',
        rebuttal TEXT NOT NULL DEFAULT '',
        sources TEXT NOT NULL DEFAULT '',
        tags TEXT NOT NULL DEFAULT '',
        updated_at TEXT NOT NULL,
        created_by_email TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )`,
    ),
    db.prepare(
      "CREATE INDEX IF NOT EXISTS documents_lookup_idx ON documents (coordinator_slug, type, uploaded_at)",
    ),
    db.prepare(
      "CREATE INDEX IF NOT EXISTS minutes_lookup_idx ON minutes (space_slug, meeting_date)",
    ),
    db.prepare(
      "CREATE INDEX IF NOT EXISTS events_lookup_idx ON events (event_date, coordinator_slug, type)",
    ),
    db.prepare(
      "CREATE INDEX IF NOT EXISTS activities_lookup_idx ON activities (year, type, campaign)",
    ),
    db.prepare(
      "CREATE INDEX IF NOT EXISTS tasks_lookup_idx ON tasks (coordinator_slug, status)",
    ),
    db.prepare(
      "CREATE INDEX IF NOT EXISTS argument_cards_lookup_idx ON argument_cards (topic, territory, type, coordinator_slug)",
    ),
  ]);

  await seedDatabase();
  initialized = true;
  initializationPromise = null;
}

async function seedDatabase() {
  const db = getBinding();
  await db.batch(
    coordinators.map((coordinator) =>
      db
        .prepare(
          `INSERT OR IGNORE INTO coordinators
            (slug, name, accent, description)
           VALUES (?, ?, ?, ?)`,
        )
        .bind(
          coordinator.slug,
          coordinator.name,
          coordinator.accent,
          coordinator.description,
        ),
    ),
  );

  const creator = "sistema@jovenesmasmadrid.local";
  const documentCount = await db
    .prepare("SELECT COUNT(*) as count FROM documents")
    .first<{ count: number }>();

  if ((documentCount?.count ?? 0) === 0) {
    await db.batch([
    db
      .prepare(
        `INSERT INTO documents
          (id, title, summary, coordinator_slug, type, uploaded_at, owner, attachment_name, attachment_url, tags, created_by_email)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .bind(
        uid("doc"),
        "Argumentario vivienda joven",
        "Documento base para intervenciones públicas y redes sobre alquiler, emancipación y vivienda pública.",
        "comunicacion",
        "argumentario",
        "2026-06-27",
        "Comunicación",
        "argumentario-vivienda.pdf",
        "https://example.com/argumentario-vivienda",
        "vivienda, emancipación, redes",
        creator,
      ),
    db
      .prepare(
        `INSERT INTO documents
          (id, title, summary, coordinator_slug, type, uploaded_at, owner, attachment_name, attachment_url, tags, created_by_email)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .bind(
        uid("doc"),
        "Protocolo de materiales para acciones",
        "Criterios de preparación, transporte y recogida de materiales para acciones de calle.",
        "logistica",
        "protocolo",
        "2026-06-24",
        "Logística",
        "protocolo-materiales",
        "",
        "acciones, materiales, turnos",
        creator,
      ),
    db
      .prepare(
        `INSERT INTO minutes
          (id, title, meeting_date, space_slug, attendees, agenda, agreements, assigned_tasks, next_meeting, body, created_by_email)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .bind(
        uid("acta"),
        "Reunión de campaña de verano",
        "2026-06-26",
        "estrategia",
        "Estrategia, Comunicación, Agitprop",
        "Objetivos de campaña; mapa de barrios; reparto de tareas",
        "Priorizar vivienda y transporte joven; preparar calendario de julio.",
        "Comunicación redacta piezas; Logística reserva materiales; Agitprop propone formato de calle.",
        "2026-07-05",
        "Se acuerda trabajar una campaña breve, con materiales reutilizables y balance a final de mes.",
        creator,
      ),
    db
      .prepare(
        `INSERT INTO minutes
          (id, title, meeting_date, space_slug, attendees, agenda, agreements, assigned_tasks, next_meeting, body, created_by_email)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .bind(
        uid("acta"),
        "Coordinadora de Ideología",
        "2026-06-20",
        "ideologia",
        "Equipo de formación",
        "Escuela de verano; lecturas; metodología",
        "Lanzar un ciclo de tres sesiones sobre municipalismo joven.",
        "Preparar dossier; cerrar ponentes; diseñar formulario de inscripción.",
        "2026-07-03",
        "La coordinadora prioriza materiales breves y sesiones participativas.",
        creator,
      ),
    db
      .prepare(
        `INSERT INTO events
          (id, title, event_date, event_time, place, description, coordinator_slug, type, people, resource_url, created_by_email)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .bind(
        uid("evt"),
        "Reunión general de jóvenes",
        "2026-07-04",
        "18:30",
        "Sede Más Madrid",
        "Puesta en común de coordinadoras y calendario del mes.",
        "estrategia",
        "encuentro interno",
        "Equipo de coordinación",
        "",
        creator,
      ),
    db
      .prepare(
        `INSERT INTO events
          (id, title, event_date, event_time, place, description, coordinator_slug, type, people, resource_url, created_by_email)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .bind(
        uid("evt"),
        "Acción de calle por vivienda",
        "2026-07-11",
        "11:30",
        "Plaza de Lavapiés",
        "Mesa informativa, reparto de materiales y recogida de testimonios.",
        "agitprop",
        "acción de calle",
        "Agitprop y Comunicación",
        "https://example.com/materiales-vivienda",
        creator,
      ),
    db
      .prepare(
        `INSERT INTO activities
          (id, title, activity_date, year, place, description, coordinator_slugs, objective, materials, links, evaluation, tags, type, campaign, created_by_email)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .bind(
        uid("mem"),
        "Pegada joven por transporte público",
        "2026-05-18",
        2026,
        "Moncloa y Ciudad Universitaria",
        "Acción coordinada de visibilización sobre abonos, nocturnos y movilidad universitaria.",
        JSON.stringify(["agitprop", "comunicacion"]),
        "Conectar reivindicaciones juveniles con propuestas municipales concretas.",
        "Carteles, octavillas, plantilla para redes",
        "https://example.com/publicacion-transporte",
        "Buen alcance en redes y alta participación; mejorar aviso previo a militancia.",
        "transporte, universidad, calle",
        "acción de calle",
        "Movilidad joven",
        creator,
      ),
    db
      .prepare(
        `INSERT INTO activities
          (id, title, activity_date, year, place, description, coordinator_slugs, objective, materials, links, evaluation, tags, type, campaign, created_by_email)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .bind(
        uid("mem"),
        "Formación sobre municipalismo y juventud",
        "2026-04-12",
        2026,
        "Centro cultural",
        "Sesión interna de formación y debate con materiales previos.",
        JSON.stringify(["ideologia", "estrategia"]),
        "Construir lenguaje común para intervención política juvenil.",
        "Dossier de lectura, presentación, acta de debate",
        "",
        "Funcionó bien el formato de grupos pequeños; conviene cerrar conclusiones antes.",
        "formación, municipalismo, debate",
        "formación",
        "Escuela joven",
        creator,
      ),
    db
      .prepare(
        `INSERT INTO tasks
          (id, coordinator_slug, title, status, due_date, source, created_by_email)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
      )
      .bind(
        uid("tsk"),
        "comunicacion",
        "Cerrar piezas de redes para la campaña de vivienda",
        "pending",
        "2026-07-06",
        "Acta campaña de verano",
        creator,
      ),
    db
      .prepare(
        `INSERT INTO tasks
          (id, coordinator_slug, title, status, due_date, source, created_by_email)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
      )
      .bind(
        uid("tsk"),
        "logistica",
        "Confirmar inventario de mesas, pancartas y megafonía",
        "pending",
        "2026-07-08",
        "Acción vivienda",
        creator,
      ),
    ]);
  }

  const argumentCount = await db
    .prepare("SELECT COUNT(*) as count FROM argument_cards")
    .first<{ count: number }>();

  if ((argumentCount?.count ?? 0) === 0) {
    await db.batch([
      db
        .prepare(
          `INSERT INTO argument_cards
            (id, title, summary, topic, territory, type, coordinator_slug, campaign, key_messages, data_points, rebuttal, sources, tags, updated_at, created_by_email)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        )
        .bind(
          uid("arg"),
          "Vivienda joven: alquiler y emancipación",
          "Ficha para intervenciones sobre alquiler, vivienda pública y dificultad de emancipación.",
          "Vivienda",
          "Regional",
          "ficha",
          "comunicacion",
          "Vivienda joven",
          "La emancipación no puede depender de heredar renta familiar.\nMás vivienda pública y límites reales a la especulación son condiciones de libertad joven.",
          "Edad media de emancipación por encima de la media europea.\nEl alquiler se come una parte desproporcionada del salario joven.",
          "Si dicen que el mercado se regula solo, responder que décadas de desregulación han producido precios expulsivos.",
          "INE; Observatorio de Emancipación; propuestas de Más Madrid.",
          "vivienda, emancipación, alquiler",
          "2026-06-27",
          creator,
        ),
      db
        .prepare(
          `INSERT INTO argument_cards
            (id, title, summary, topic, territory, type, coordinator_slug, campaign, key_messages, data_points, rebuttal, sources, tags, updated_at, created_by_email)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        )
        .bind(
          uid("arg"),
          "Transporte nocturno y vida joven",
          "Mensajes para defender movilidad segura y accesible en fines de semana y horarios nocturnos.",
          "Transporte",
          "Madrid ciudad",
          "mensaje clave",
          "estrategia",
          "Movilidad joven",
          "Moverse de noche también es derecho a la ciudad.\nEl transporte público joven debe servir para estudiar, trabajar, militar y volver a casa con seguridad.",
          "La movilidad nocturna condiciona ocio, empleo y cuidados.\nMás frecuencia reduce dependencia del coche y trayectos inseguros.",
          "No es un gasto de ocio: es una política de seguridad, igualdad y clima.",
          "Datos CRTM; propuestas municipales; balance de acciones de movilidad.",
          "transporte, noche, movilidad",
          "2026-05-20",
          creator,
        ),
      db
        .prepare(
          `INSERT INTO argument_cards
            (id, title, summary, topic, territory, type, coordinator_slug, campaign, key_messages, data_points, rebuttal, sources, tags, updated_at, created_by_email)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        )
        .bind(
          uid("arg"),
          "Universidades: espacios de organización",
          "Ficha breve para mesas y conversaciones en campus sobre participación juvenil.",
          "Educación",
          "Universidades",
          "respuesta rápida",
          "agitprop",
          "Curso político",
          "La universidad no es solo aula: también es barrio, precariedad, transporte, alquiler y salud mental.\nOrganizarse permite convertir malestar individual en fuerza colectiva.",
          "Aumento de costes asociados a estudiar en Madrid.\nDesigualdad territorial entre campus y municipios.",
          "Frente a la idea de que la política sobra en la universidad: estudiar también es vivir en sociedad.",
          "Diagnósticos estudiantiles; materiales de Ideología; actas de campaña.",
          "universidad, organización, estudiantes",
          "2026-04-14",
          creator,
        ),
    ]);
  }
}

export async function getOrCreateProfile(input: {
  email: string;
  name: string;
}): Promise<UserProfile> {
  await ensureDatabase();
  const db = getBinding();
  const existing = await db
    .prepare(
      `SELECT email, name, role, coordinator_slug
       FROM users
       WHERE email = ?`,
    )
    .bind(input.email)
    .first<StoredUser>();
  if (existing) return mapUser(existing);

  const count = await db
    .prepare("SELECT COUNT(*) as count FROM users")
    .first<{ count: number }>();
  const role: Role = (count?.count ?? 0) === 0 ? "admin" : "internal";

  await db
    .prepare(
      `INSERT INTO users (email, name, role, coordinator_slug)
       VALUES (?, ?, ?, ?)`,
    )
    .bind(input.email, input.name, role, null)
    .run();

  return {
    email: input.email,
    name: input.name,
    role,
    coordinatorSlug: null,
  };
}

export async function listUsers() {
  await ensureDatabase();
  const rows = await getBinding()
    .prepare(
      `SELECT email, name, role, coordinator_slug
       FROM users
       ORDER BY created_at ASC`,
    )
    .all<StoredUser>();
  return rows.results.map(mapUser);
}

export async function getDashboardData() {
  const [documents, minutes, events, activities, tasks, argumentCards] =
    await Promise.all([
      listDocuments({ limit: 5 }),
      listMinutes({ limit: 5 }),
      listEvents({ from: todayIso(), limit: 6 }),
      listActivities({ limit: 5 }),
      listTasks({ status: "pending" }),
      listArgumentCards({ limit: 5 }),
    ]);
  return { documents, minutes, events, activities, tasks, argumentCards };
}

export async function listDocuments(filters: {
  search?: string;
  coordinator?: string;
  type?: string;
  from?: string;
  to?: string;
  limit?: number;
} = {}) {
  await ensureDatabase();
  const clauses: string[] = [];
  const values: BindValue[] = [];
  const search = normalizeSearch(filters.search);
  if (search) {
    clauses.push(
      "(lower(title) LIKE ? OR lower(summary) LIKE ? OR lower(tags) LIKE ? OR lower(owner) LIKE ?)",
    );
    values.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`);
  }
  if (filters.coordinator) {
    clauses.push("coordinator_slug = ?");
    values.push(filters.coordinator);
  }
  if (filters.type) {
    clauses.push("type = ?");
    values.push(filters.type);
  }
  if (filters.from) {
    clauses.push("uploaded_at >= ?");
    values.push(filters.from);
  }
  if (filters.to) {
    clauses.push("uploaded_at <= ?");
    values.push(filters.to);
  }

  const limit = Math.min(filters.limit ?? 80, 120);
  const sql = `SELECT * FROM documents ${
    clauses.length ? `WHERE ${clauses.join(" AND ")}` : ""
  } ORDER BY uploaded_at DESC, created_at DESC LIMIT ?`;
  const rows = await getBinding()
    .prepare(sql)
    .bind(...values, limit)
    .all<StoredDocument>();
  return rows.results.map(mapDocument);
}

export async function listMinutes(filters: {
  search?: string;
  space?: string;
  limit?: number;
} = {}) {
  await ensureDatabase();
  const clauses: string[] = [];
  const values: BindValue[] = [];
  const search = normalizeSearch(filters.search);
  if (search) {
    clauses.push(
      "(lower(title) LIKE ? OR lower(agenda) LIKE ? OR lower(agreements) LIKE ? OR lower(assigned_tasks) LIKE ?)",
    );
    values.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`);
  }
  if (filters.space) {
    clauses.push("space_slug = ?");
    values.push(filters.space);
  }

  const limit = Math.min(filters.limit ?? 80, 120);
  const sql = `SELECT * FROM minutes ${
    clauses.length ? `WHERE ${clauses.join(" AND ")}` : ""
  } ORDER BY meeting_date DESC, created_at DESC LIMIT ?`;
  const rows = await getBinding()
    .prepare(sql)
    .bind(...values, limit)
    .all<StoredMinute>();
  return rows.results.map(mapMinute);
}

export async function listEvents(filters: {
  search?: string;
  coordinator?: string;
  type?: string;
  from?: string;
  to?: string;
  limit?: number;
} = {}) {
  await ensureDatabase();
  const clauses: string[] = [];
  const values: BindValue[] = [];
  const search = normalizeSearch(filters.search);
  if (search) {
    clauses.push(
      "(lower(title) LIKE ? OR lower(place) LIKE ? OR lower(description) LIKE ? OR lower(people) LIKE ?)",
    );
    values.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`);
  }
  if (filters.coordinator) {
    clauses.push("coordinator_slug = ?");
    values.push(filters.coordinator);
  }
  if (filters.type) {
    clauses.push("type = ?");
    values.push(filters.type);
  }
  if (filters.from) {
    clauses.push("event_date >= ?");
    values.push(filters.from);
  }
  if (filters.to) {
    clauses.push("event_date <= ?");
    values.push(filters.to);
  }

  const limit = Math.min(filters.limit ?? 120, 180);
  const sql = `SELECT * FROM events ${
    clauses.length ? `WHERE ${clauses.join(" AND ")}` : ""
  } ORDER BY event_date ASC, event_time ASC LIMIT ?`;
  const rows = await getBinding()
    .prepare(sql)
    .bind(...values, limit)
    .all<StoredEvent>();
  return rows.results.map(mapEvent);
}

export async function listActivities(filters: {
  search?: string;
  coordinator?: string;
  year?: string;
  type?: string;
  campaign?: string;
  limit?: number;
} = {}) {
  await ensureDatabase();
  const clauses: string[] = [];
  const values: BindValue[] = [];
  const search = normalizeSearch(filters.search);
  if (search) {
    clauses.push(
      "(lower(title) LIKE ? OR lower(description) LIKE ? OR lower(objective) LIKE ? OR lower(tags) LIKE ? OR lower(campaign) LIKE ?)",
    );
    values.push(
      `%${search}%`,
      `%${search}%`,
      `%${search}%`,
      `%${search}%`,
      `%${search}%`,
    );
  }
  if (filters.coordinator) {
    clauses.push("coordinator_slugs LIKE ?");
    values.push(`%"${filters.coordinator}"%`);
  }
  if (filters.year) {
    clauses.push("year = ?");
    values.push(Number(filters.year));
  }
  if (filters.type) {
    clauses.push("type = ?");
    values.push(filters.type);
  }
  if (filters.campaign) {
    clauses.push("campaign = ?");
    values.push(filters.campaign);
  }

  const limit = Math.min(filters.limit ?? 100, 160);
  const sql = `SELECT * FROM activities ${
    clauses.length ? `WHERE ${clauses.join(" AND ")}` : ""
  } ORDER BY activity_date DESC, created_at DESC LIMIT ?`;
  const rows = await getBinding()
    .prepare(sql)
    .bind(...values, limit)
    .all<StoredActivity>();
  return rows.results.map(mapActivity);
}

export async function listArgumentCards(filters: {
  search?: string;
  topic?: string;
  territory?: string;
  type?: string;
  coordinator?: string;
  campaign?: string;
  limit?: number;
} = {}) {
  await ensureDatabase();
  const clauses: string[] = [];
  const values: BindValue[] = [];
  const search = normalizeSearch(filters.search);
  if (search) {
    clauses.push(
      "(lower(title) LIKE ? OR lower(summary) LIKE ? OR lower(topic) LIKE ? OR lower(territory) LIKE ? OR lower(key_messages) LIKE ? OR lower(data_points) LIKE ? OR lower(rebuttal) LIKE ? OR lower(tags) LIKE ?)",
    );
    values.push(
      `%${search}%`,
      `%${search}%`,
      `%${search}%`,
      `%${search}%`,
      `%${search}%`,
      `%${search}%`,
      `%${search}%`,
      `%${search}%`,
    );
  }
  if (filters.topic) {
    clauses.push("topic = ?");
    values.push(filters.topic);
  }
  if (filters.territory) {
    clauses.push("territory = ?");
    values.push(filters.territory);
  }
  if (filters.type) {
    clauses.push("type = ?");
    values.push(filters.type);
  }
  if (filters.coordinator) {
    clauses.push("coordinator_slug = ?");
    values.push(filters.coordinator);
  }
  if (filters.campaign) {
    clauses.push("campaign = ?");
    values.push(filters.campaign);
  }

  const limit = Math.min(filters.limit ?? 120, 180);
  const sql = `SELECT * FROM argument_cards ${
    clauses.length ? `WHERE ${clauses.join(" AND ")}` : ""
  } ORDER BY topic ASC, territory ASC, updated_at DESC, created_at DESC LIMIT ?`;
  const rows = await getBinding()
    .prepare(sql)
    .bind(...values, limit)
    .all<StoredArgumentCard>();
  return rows.results.map(mapArgumentCard);
}

export async function listTasks(filters: {
  coordinator?: string;
  status?: "pending" | "done";
} = {}) {
  await ensureDatabase();
  const clauses: string[] = [];
  const values: BindValue[] = [];
  if (filters.coordinator) {
    clauses.push("coordinator_slug = ?");
    values.push(filters.coordinator);
  }
  if (filters.status) {
    clauses.push("status = ?");
    values.push(filters.status);
  }
  const rows = await getBinding()
    .prepare(
      `SELECT * FROM tasks ${
        clauses.length ? `WHERE ${clauses.join(" AND ")}` : ""
      } ORDER BY due_date ASC, created_at DESC`,
    )
    .bind(...values)
    .all<StoredTask>();
  return rows.results.map(mapTask);
}

export async function getCoordinatorBundle(slug: CoordinatorSlug) {
  const [documents, minutes, events, activities, tasks, argumentCards] =
    await Promise.all([
      listDocuments({ coordinator: slug }),
      listMinutes({ space: slug }),
      listEvents({ coordinator: slug }),
      listActivities({ coordinator: slug }),
      listTasks({ coordinator: slug }),
      listArgumentCards({ coordinator: slug }),
    ]);
  return { documents, minutes, events, activities, tasks, argumentCards };
}

export async function distinctActivityYears() {
  await ensureDatabase();
  const rows = await getBinding()
    .prepare("SELECT DISTINCT year FROM activities ORDER BY year DESC")
    .all<{ year: number }>();
  return rows.results.map((row) => String(row.year));
}

export async function distinctCampaigns() {
  await ensureDatabase();
  const rows = await getBinding()
    .prepare(
      "SELECT DISTINCT campaign FROM activities WHERE campaign != '' ORDER BY campaign ASC",
    )
    .all<{ campaign: string }>();
  return rows.results.map((row) => row.campaign);
}

export async function distinctArgumentTopics() {
  await ensureDatabase();
  const rows = await getBinding()
    .prepare(
      "SELECT DISTINCT topic FROM argument_cards WHERE topic != '' ORDER BY topic ASC",
    )
    .all<{ topic: string }>();
  return rows.results.map((row) => row.topic);
}

export async function distinctArgumentTerritories() {
  await ensureDatabase();
  const rows = await getBinding()
    .prepare(
      "SELECT DISTINCT territory FROM argument_cards WHERE territory != '' ORDER BY territory ASC",
    )
    .all<{ territory: string }>();
  return rows.results.map((row) => row.territory);
}

export async function distinctArgumentCampaigns() {
  await ensureDatabase();
  const rows = await getBinding()
    .prepare(
      "SELECT DISTINCT campaign FROM argument_cards WHERE campaign != '' ORDER BY campaign ASC",
    )
    .all<{ campaign: string }>();
  return rows.results.map((row) => row.campaign);
}

export async function createDocument(input: Omit<InternalDocument, "createdAt">) {
  await ensureDatabase();
  await getBinding()
    .prepare(
      `INSERT INTO documents
        (id, title, summary, coordinator_slug, type, uploaded_at, owner, attachment_name, attachment_url, tags, created_by_email)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .bind(
      input.id,
      input.title,
      input.summary,
      input.coordinatorSlug,
      input.type,
      input.uploadedAt,
      input.owner,
      input.attachmentName,
      input.attachmentUrl,
      input.tags,
      input.createdByEmail,
    )
    .run();
}

export async function createMinute(input: Omit<MeetingMinute, "createdAt">) {
  await ensureDatabase();
  await getBinding()
    .prepare(
      `INSERT INTO minutes
        (id, title, meeting_date, space_slug, attendees, agenda, agreements, assigned_tasks, next_meeting, attachment_url, body, created_by_email)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .bind(
      input.id,
      input.title,
      input.meetingDate,
      input.spaceSlug,
      input.attendees,
      input.agenda,
      input.agreements,
      input.assignedTasks,
      input.nextMeeting,
      input.attachmentUrl,
      input.body,
      input.createdByEmail,
    )
    .run();
}

export async function createEvent(input: Omit<InternalEvent, "createdAt">) {
  await ensureDatabase();
  await getBinding()
    .prepare(
      `INSERT INTO events
        (id, title, event_date, event_time, place, description, coordinator_slug, type, people, resource_url, created_by_email)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .bind(
      input.id,
      input.title,
      input.eventDate,
      input.eventTime,
      input.place,
      input.description,
      input.coordinatorSlug,
      input.type,
      input.people,
      input.resourceUrl,
      input.createdByEmail,
    )
    .run();
}

export async function createActivity(input: Omit<Activity, "createdAt">) {
  await ensureDatabase();
  await getBinding()
    .prepare(
      `INSERT INTO activities
        (id, title, activity_date, year, place, description, coordinator_slugs, objective, materials, links, evaluation, tags, type, campaign, created_by_email)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .bind(
      input.id,
      input.title,
      input.activityDate,
      input.year,
      input.place,
      input.description,
      JSON.stringify(input.coordinatorSlugs),
      input.objective,
      input.materials,
      input.links,
      input.evaluation,
      input.tags,
      input.type,
      input.campaign,
      input.createdByEmail,
    )
    .run();
}

export async function createArgumentCard(input: Omit<ArgumentCard, "createdAt">) {
  await ensureDatabase();
  await getBinding()
    .prepare(
      `INSERT INTO argument_cards
        (id, title, summary, topic, territory, type, coordinator_slug, campaign, key_messages, data_points, rebuttal, sources, tags, updated_at, created_by_email)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .bind(
      input.id,
      input.title,
      input.summary,
      input.topic,
      input.territory,
      input.type,
      input.coordinatorSlug,
      input.campaign,
      input.keyMessages,
      input.dataPoints,
      input.rebuttal,
      input.sources,
      input.tags,
      input.updatedAt,
      input.createdByEmail,
    )
    .run();
}

export async function createTask(input: Omit<CoordinatorTask, "createdAt">) {
  await ensureDatabase();
  await getBinding()
    .prepare(
      `INSERT INTO tasks
        (id, coordinator_slug, title, status, due_date, source, created_by_email)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
    )
    .bind(
      input.id,
      input.coordinatorSlug,
      input.title,
      input.status,
      input.dueDate,
      input.source,
      input.createdByEmail,
    )
    .run();
}

export async function deleteRecord(
  table:
    | "documents"
    | "minutes"
    | "events"
    | "activities"
    | "tasks"
    | "argument_cards",
  id: string,
) {
  await ensureDatabase();
  const existing = await getBinding()
    .prepare(`SELECT * FROM ${table} WHERE id = ?`)
    .bind(id)
    .first<Record<string, string>>();
  if (!existing) return null;
  await getBinding().prepare(`DELETE FROM ${table} WHERE id = ?`).bind(id).run();
  return existing;
}

export async function getRecordScope(
  table:
    | "documents"
    | "minutes"
    | "events"
    | "activities"
    | "tasks"
    | "argument_cards",
  id: string,
) {
  await ensureDatabase();
  if (
    table === "documents" ||
    table === "events" ||
    table === "tasks" ||
    table === "argument_cards"
  ) {
    const row = await getBinding()
      .prepare(`SELECT coordinator_slug FROM ${table} WHERE id = ?`)
      .bind(id)
      .first<{ coordinator_slug: CoordinatorSlug }>();
    return row?.coordinator_slug ?? null;
  }
  if (table === "minutes") {
    const row = await getBinding()
      .prepare("SELECT space_slug FROM minutes WHERE id = ?")
      .bind(id)
      .first<{ space_slug: CoordinatorSlug | "general" }>();
    return row?.space_slug ?? null;
  }
  const row = await getBinding()
    .prepare("SELECT coordinator_slugs FROM activities WHERE id = ?")
    .bind(id)
    .first<{ coordinator_slugs: string }>();
  return row ? safeParseCoordinators(row.coordinator_slugs) : null;
}

type StoredUser = {
  email: string;
  name: string;
  role: Role;
  coordinator_slug: CoordinatorSlug | null;
};

type StoredDocument = {
  id: string;
  title: string;
  summary: string;
  coordinator_slug: CoordinatorSlug;
  type: DocumentType;
  uploaded_at: string;
  owner: string;
  attachment_name: string;
  attachment_url: string;
  tags: string;
  created_by_email: string;
  created_at: string;
};

type StoredMinute = {
  id: string;
  title: string;
  meeting_date: string;
  space_slug: CoordinatorSlug | "general";
  attendees: string;
  agenda: string;
  agreements: string;
  assigned_tasks: string;
  next_meeting: string;
  attachment_url: string;
  body: string;
  created_by_email: string;
  created_at: string;
};

type StoredEvent = {
  id: string;
  title: string;
  event_date: string;
  event_time: string;
  place: string;
  description: string;
  coordinator_slug: CoordinatorSlug;
  type: InternalEvent["type"];
  people: string;
  resource_url: string;
  created_by_email: string;
  created_at: string;
};

type StoredActivity = {
  id: string;
  title: string;
  activity_date: string;
  year: number;
  place: string;
  description: string;
  coordinator_slugs: string;
  objective: string;
  materials: string;
  links: string;
  evaluation: string;
  tags: string;
  type: string;
  campaign: string;
  created_by_email: string;
  created_at: string;
};

type StoredTask = {
  id: string;
  coordinator_slug: CoordinatorSlug;
  title: string;
  status: "pending" | "done";
  due_date: string;
  source: string;
  created_by_email: string;
  created_at: string;
};

type StoredArgumentCard = {
  id: string;
  title: string;
  summary: string;
  topic: string;
  territory: string;
  type: ArgumentCardType;
  coordinator_slug: CoordinatorSlug;
  campaign: string;
  key_messages: string;
  data_points: string;
  rebuttal: string;
  sources: string;
  tags: string;
  updated_at: string;
  created_by_email: string;
  created_at: string;
};

function mapUser(row: StoredUser): UserProfile {
  return {
    email: row.email,
    name: row.name,
    role: row.role,
    coordinatorSlug: row.coordinator_slug,
  };
}

function mapDocument(row: StoredDocument): InternalDocument {
  return {
    id: row.id,
    title: row.title,
    summary: row.summary,
    coordinatorSlug: row.coordinator_slug,
    type: row.type,
    uploadedAt: row.uploaded_at,
    owner: row.owner,
    attachmentName: row.attachment_name,
    attachmentUrl: row.attachment_url,
    tags: row.tags,
    createdByEmail: row.created_by_email,
    createdAt: row.created_at,
  };
}

function mapMinute(row: StoredMinute): MeetingMinute {
  return {
    id: row.id,
    title: row.title,
    meetingDate: row.meeting_date,
    spaceSlug: row.space_slug,
    attendees: row.attendees,
    agenda: row.agenda,
    agreements: row.agreements,
    assignedTasks: row.assigned_tasks,
    nextMeeting: row.next_meeting,
    attachmentUrl: row.attachment_url,
    body: row.body,
    createdByEmail: row.created_by_email,
    createdAt: row.created_at,
  };
}

function mapEvent(row: StoredEvent): InternalEvent {
  return {
    id: row.id,
    title: row.title,
    eventDate: row.event_date,
    eventTime: row.event_time,
    place: row.place,
    description: row.description,
    coordinatorSlug: row.coordinator_slug,
    type: row.type,
    people: row.people,
    resourceUrl: row.resource_url,
    createdByEmail: row.created_by_email,
    createdAt: row.created_at,
  };
}

function mapActivity(row: StoredActivity): Activity {
  return {
    id: row.id,
    title: row.title,
    activityDate: row.activity_date,
    year: row.year,
    place: row.place,
    description: row.description,
    coordinatorSlugs: safeParseCoordinators(row.coordinator_slugs),
    objective: row.objective,
    materials: row.materials,
    links: row.links,
    evaluation: row.evaluation,
    tags: row.tags,
    type: row.type,
    campaign: row.campaign,
    createdByEmail: row.created_by_email,
    createdAt: row.created_at,
  };
}

function mapTask(row: StoredTask): CoordinatorTask {
  return {
    id: row.id,
    coordinatorSlug: row.coordinator_slug,
    title: row.title,
    status: row.status,
    dueDate: row.due_date,
    source: row.source,
    createdByEmail: row.created_by_email,
    createdAt: row.created_at,
  };
}

function mapArgumentCard(row: StoredArgumentCard): ArgumentCard {
  return {
    id: row.id,
    title: row.title,
    summary: row.summary,
    topic: row.topic,
    territory: row.territory,
    type: row.type,
    coordinatorSlug: row.coordinator_slug,
    campaign: row.campaign,
    keyMessages: row.key_messages,
    dataPoints: row.data_points,
    rebuttal: row.rebuttal,
    sources: row.sources,
    tags: row.tags,
    updatedAt: row.updated_at,
    createdByEmail: row.created_by_email,
    createdAt: row.created_at,
  };
}

function safeParseCoordinators(value: string): CoordinatorSlug[] {
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}
