# Jóvenes Más Madrid · Archivo interno

Web privada para organización, archivo y memoria interna de Jóvenes Más Madrid.

## Qué incluye

- Dashboard interno.
- Coordinadoras: Comunicación, Ideología, Estrategia, Logística y Agitprop.
- Documentos y actas.
- Calendario interno.
- Memoria de actividades.
- Argumentario con fichas agrupables por temática, territorio, campaña y coordinadora.
- Roles: administrador/a, coordinador/a y usuario/a interno.
- Persistencia con D1 y adjuntos con R2 en Sites.
- Acceso privado mediante Sign in with ChatGPT/Sites.

## Requisitos

- Node.js `>=22.13.0`
- npm

## Desarrollo local

```bash
npm install
npm run dev
```

Después abre `http://localhost:3000`.

## Validación

```bash
npm run build
npm run lint
```

## Despliegue

El proyecto está preparado para OpenAI Sites/Cloudflare Worker compatible.

Los bindings están declarados en `.openai/hosting.json`:

- `DB`: base de datos D1.
- `FILES`: almacenamiento R2 para adjuntos.

Las rutas privadas usan los helpers de `app/chatgpt-auth.ts`. En local se usa un usuario de desarrollo para poder probar la app sin pasar por el flujo real de login.

## Estructura principal

- `app/`: páginas, rutas y acciones de servidor.
- `components/`: componentes reutilizables de interfaz.
- `lib/`: catálogo, tipos, sesión y repositorio de datos.
- `db/schema.ts`: modelo de datos.
- `worker/`: entrada Worker.
- `.openai/hosting.json`: configuración lógica de Sites.
