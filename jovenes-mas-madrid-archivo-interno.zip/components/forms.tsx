import {
  addActivity,
  addArgumentCard,
  addDocument,
  addEvent,
  addMinute,
  addTask,
} from "../app/actions";
import {
  activityTypes,
  argumentCardTypes,
  coordinators,
  defaultArgumentTopics,
  defaultTerritories,
  documentTypes,
  eventTypes,
} from "../lib/catalog";
import { canManage } from "../lib/session";
import type { CoordinatorSlug, UserProfile } from "../lib/types";
import { todayIso } from "../lib/utils";

export function DocumentForm({ profile }: { profile: UserProfile }) {
  const options = writableCoordinators(profile);
  if (!options.length) return <ReadOnlyNotice />;
  return (
    <form action={addDocument} className="grid gap-3">
      <Field label="Título" name="title" required />
      <Textarea label="Descripción breve" name="summary" />
      <div className="grid gap-3 md:grid-cols-3">
        <Select label="Coordinadora" name="coordinatorSlug" options={options} />
        <Select
          label="Tipo"
          name="type"
          options={documentTypes.map((type) => ({ label: type, value: type }))}
        />
        <Field label="Fecha de subida" name="uploadedAt" type="date" value={todayIso()} />
      </div>
      <div className="grid gap-3 md:grid-cols-2">
        <Field label="Responsable" name="owner" required />
        <Field label="Etiquetas" name="tags" placeholder="vivienda, redes" />
      </div>
      <div className="grid gap-3 md:grid-cols-2">
        <Field label="Archivo adjunto" name="file" type="file" />
        <Field label="Enlace externo" name="attachmentUrl" placeholder="https://" />
      </div>
      <Field label="Nombre del adjunto" name="attachmentName" />
      <Submit>Guardar documento</Submit>
    </form>
  );
}

export function MinuteForm({ profile }: { profile: UserProfile }) {
  const spaces = minuteSpaces(profile);
  if (!spaces.length) return <ReadOnlyNotice />;
  return (
    <form action={addMinute} className="grid gap-3">
      <Field label="Título de la reunión" name="title" required />
      <div className="grid gap-3 md:grid-cols-3">
        <Field label="Fecha" name="meetingDate" required type="date" value={todayIso()} />
        <Select label="Espacio" name="spaceSlug" options={spaces} />
        <Field label="Próxima reunión" name="nextMeeting" type="date" />
      </div>
      <Field label="Asistentes" name="attendees" />
      <Textarea label="Orden del día" name="agenda" />
      <Textarea label="Acuerdos alcanzados" name="agreements" />
      <Textarea label="Tareas asignadas" name="assignedTasks" />
      <Textarea label="Contenido del acta" name="body" rows={5} />
      <div className="grid gap-3 md:grid-cols-2">
        <Field label="Archivo adjunto" name="file" type="file" />
        <Field label="Enlace externo" name="attachmentUrl" placeholder="https://" />
      </div>
      <Submit>Guardar acta</Submit>
    </form>
  );
}

export function EventForm({ profile }: { profile: UserProfile }) {
  const options = writableCoordinators(profile);
  if (!options.length) return <ReadOnlyNotice />;
  return (
    <form action={addEvent} className="grid gap-3">
      <Field label="Título" name="title" required />
      <div className="grid gap-3 md:grid-cols-4">
        <Field label="Fecha" name="eventDate" required type="date" value={todayIso()} />
        <Field label="Hora" name="eventTime" type="time" />
        <Select label="Coordinadora" name="coordinatorSlug" options={options} />
        <Select
          label="Tipo"
          name="type"
          options={eventTypes.map((type) => ({ label: type, value: type }))}
        />
      </div>
      <Field label="Lugar" name="place" />
      <Textarea label="Descripción" name="description" />
      <div className="grid gap-3 md:grid-cols-2">
        <Field label="Personas responsables" name="people" />
        <Field label="Enlace o documentación" name="resourceUrl" placeholder="https://" />
      </div>
      <Submit>Guardar evento</Submit>
    </form>
  );
}

export function ActivityForm({ profile }: { profile: UserProfile }) {
  const options = writableCoordinators(profile);
  if (!options.length) return <ReadOnlyNotice />;
  return (
    <form action={addActivity} className="grid gap-3">
      <Field label="Título" name="title" required />
      <div className="grid gap-3 md:grid-cols-3">
        <Field label="Fecha" name="activityDate" required type="date" value={todayIso()} />
        <Field label="Lugar" name="place" />
        <Select
          label="Tipo"
          name="type"
          options={activityTypes.map((type) => ({ label: type, value: type }))}
        />
      </div>
      <fieldset className="rounded-lg border border-[var(--line)] p-3">
        <legend className="px-1 text-sm font-black text-zinc-700">
          Coordinadoras implicadas
        </legend>
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {options.map((option) => (
            <label className="flex items-center gap-2 text-sm font-semibold" key={option.value}>
              <input
                className="size-4 accent-[var(--primary)]"
                defaultChecked={options.length === 1}
                name="coordinatorSlugs"
                type="checkbox"
                value={option.value}
              />
              {option.label}
            </label>
          ))}
        </div>
      </fieldset>
      <Textarea label="Descripción de la actividad" name="description" />
      <Textarea label="Objetivo político u organizativo" name="objective" />
      <Textarea label="Materiales utilizados" name="materials" />
      <Textarea label="Balance o valoración posterior" name="evaluation" />
      <div className="grid gap-3 md:grid-cols-3">
        <Field label="Fotos o publicaciones" name="links" placeholder="https://" />
        <Field label="Campaña" name="campaign" />
        <Field label="Etiquetas" name="tags" />
      </div>
      <Submit>Guardar actividad</Submit>
    </form>
  );
}

export function ArgumentCardForm({ profile }: { profile: UserProfile }) {
  const options = writableCoordinators(profile);
  if (!options.length) return <ReadOnlyNotice />;
  return (
    <form action={addArgumentCard} className="grid gap-3">
      <Field label="Título de la ficha" name="title" required />
      <Textarea label="Resumen breve" name="summary" />
      <div className="grid gap-3 md:grid-cols-3">
        <Field
          label="Temática"
          list="argument-topics"
          name="topic"
          placeholder="Vivienda"
          required
        />
        <Field
          label="Territorio"
          list="argument-territories"
          name="territory"
          placeholder="Madrid ciudad"
        />
        <Select
          label="Tipo"
          name="type"
          options={argumentCardTypes.map((type) => ({
            label: type,
            value: type,
          }))}
        />
      </div>
      <div className="grid gap-3 md:grid-cols-3">
        <Select label="Coordinadora" name="coordinatorSlug" options={options} />
        <Field label="Campaña" name="campaign" placeholder="Vivienda joven" />
        <Field
          label="Última actualización"
          name="updatedAt"
          type="date"
          value={todayIso()}
        />
      </div>
      <Textarea label="Mensajes clave" name="keyMessages" rows={4} />
      <Textarea label="Datos o cifras útiles" name="dataPoints" rows={3} />
      <Textarea label="Respuesta a críticas o marcos contrarios" name="rebuttal" rows={3} />
      <Textarea label="Fuentes y enlaces" name="sources" rows={3} />
      <Field label="Etiquetas" name="tags" placeholder="vivienda, alquiler, emancipación" />
      <datalist id="argument-topics">
        {defaultArgumentTopics.map((topic) => (
          <option key={topic} value={topic} />
        ))}
      </datalist>
      <datalist id="argument-territories">
        {defaultTerritories.map((territory) => (
          <option key={territory} value={territory} />
        ))}
      </datalist>
      <Submit>Guardar ficha</Submit>
    </form>
  );
}

export function TaskForm({
  defaultCoordinator,
  profile,
}: {
  defaultCoordinator: CoordinatorSlug;
  profile: UserProfile;
}) {
  if (!canManage(profile, defaultCoordinator)) return null;
  return (
    <form action={addTask} className="grid gap-3">
      <input name="coordinatorSlug" type="hidden" value={defaultCoordinator} />
      <Field label="Nueva tarea o acuerdo pendiente" name="title" required />
      <div className="grid gap-3 md:grid-cols-2">
        <Field label="Fecha límite" name="dueDate" type="date" />
        <Field label="Origen" name="source" placeholder="Acta, campaña, reunión" />
      </div>
      <Submit>Añadir tarea</Submit>
    </form>
  );
}

function Field({
  list,
  label,
  name,
  placeholder,
  required,
  type = "text",
  value,
}: {
  list?: string;
  label: string;
  name: string;
  placeholder?: string;
  required?: boolean;
  type?: string;
  value?: string;
}) {
  return (
    <label className="grid gap-1.5 text-sm font-bold text-zinc-700">
      {label}
      <input
        className="focus-ring min-h-11 rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm font-medium text-zinc-900"
        defaultValue={value}
        list={list}
        name={name}
        placeholder={placeholder}
        required={required}
        type={type}
      />
    </label>
  );
}

function Textarea({
  label,
  name,
  rows = 3,
}: {
  label: string;
  name: string;
  rows?: number;
}) {
  return (
    <label className="grid gap-1.5 text-sm font-bold text-zinc-700">
      {label}
      <textarea
        className="focus-ring rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm font-medium leading-6 text-zinc-900"
        name={name}
        rows={rows}
      />
    </label>
  );
}

function Select({
  label,
  name,
  options,
}: {
  label: string;
  name: string;
  options: { label: string; value: string }[];
}) {
  return (
    <label className="grid gap-1.5 text-sm font-bold text-zinc-700">
      {label}
      <select
        className="focus-ring min-h-11 rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm font-bold text-zinc-900"
        name={name}
      >
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </label>
  );
}

function Submit({ children }: { children: React.ReactNode }) {
  return (
    <button
      className="focus-ring inline-flex min-h-11 w-fit items-center rounded-md bg-[var(--primary)] px-4 py-2 text-sm font-black text-white hover:bg-[var(--primary-dark)]"
      type="submit"
    >
      {children}
    </button>
  );
}

function ReadOnlyNotice() {
  return (
    <div className="rounded-lg border border-[var(--line)] bg-zinc-50 p-4 text-sm font-semibold text-zinc-600">
      Tu rol actual permite consulta. La edición queda reservada a administración
      y coordinadoras.
    </div>
  );
}

function writableCoordinators(profile: UserProfile) {
  if (profile.role === "admin") {
    return coordinators.map((coordinator) => ({
      label: coordinator.name,
      value: coordinator.slug,
    }));
  }
  if (profile.role === "coordinator" && profile.coordinatorSlug) {
    const coordinator = coordinators.find(
      (item) => item.slug === profile.coordinatorSlug,
    );
    return coordinator
      ? [{ label: coordinator.name, value: coordinator.slug }]
      : [];
  }
  return [];
}

function minuteSpaces(profile: UserProfile) {
  const spaces = writableCoordinators(profile);
  if (profile.role === "admin") {
    return [{ label: "General", value: "general" }, ...spaces];
  }
  return spaces;
}
