import Link from "next/link";
import { coordinators } from "../lib/catalog";
import { roleLabel, signOutPath } from "../lib/session";
import type { UserProfile } from "../lib/types";

const navItems = [
  { href: "/", label: "Dashboard" },
  { href: "/argumentario", label: "Argumentario" },
  { href: "/documentos", label: "Documentos" },
  { href: "/actas", label: "Actas" },
  { href: "/calendario", label: "Calendario" },
  { href: "/memoria", label: "Memoria" },
  { href: "/roles", label: "Roles" },
];

export function AppShell({
  children,
  current,
  profile,
}: {
  children: React.ReactNode;
  current: string;
  profile: UserProfile;
}) {
  return (
    <main className="min-h-screen bg-[var(--background)] text-[var(--ink)]">
      <div className="flex min-h-screen flex-col lg:flex-row">
        <aside className="border-b border-[var(--line)] bg-white lg:sticky lg:top-0 lg:h-screen lg:w-72 lg:border-b-0 lg:border-r">
          <div className="flex h-full flex-col gap-6 p-4 sm:p-5">
            <Link href="/" className="focus-ring rounded-lg">
              <div className="flex items-center gap-3">
                <div className="grid size-11 place-items-center rounded-lg bg-[var(--primary)] text-lg font-black text-white">
                  JM
                </div>
                <div>
                  <p className="text-sm font-black uppercase leading-none">
                    Jóvenes
                  </p>
                  <p className="text-sm font-black uppercase leading-none text-[var(--primary)]">
                    Más Madrid
                  </p>
                </div>
              </div>
            </Link>

            <nav className="grid grid-cols-2 gap-2 pb-1 sm:grid-cols-3 lg:flex lg:flex-col lg:pb-0">
              {navItems.map((item) => (
                <Link
                  className={`focus-ring whitespace-nowrap rounded-md px-3 py-2 text-sm font-semibold transition ${
                    current === item.href
                      ? "bg-[var(--primary)] text-white"
                      : "text-zinc-700 hover:bg-[var(--surface-soft)]"
                  }`}
                  href={item.href}
                  key={item.href}
                >
                  {item.label}
                </Link>
              ))}
            </nav>

            <div className="hidden flex-col gap-2 lg:flex">
              <p className="px-3 text-xs font-bold uppercase text-zinc-500">
                Coordinadoras
              </p>
              {coordinators.map((coordinator) => (
                <Link
                  className="focus-ring flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium text-zinc-700 hover:bg-[var(--surface-soft)]"
                  href={`/coordinadoras/${coordinator.slug}`}
                  key={coordinator.slug}
                >
                  <span
                    className="size-2.5 rounded-full"
                    style={{ backgroundColor: coordinator.accent }}
                  />
                  {coordinator.name}
                </Link>
              ))}
            </div>

            <div className="mt-auto rounded-lg border border-[var(--line)] bg-[var(--surface-soft)] p-3">
              <p className="truncate text-sm font-bold">{profile.name}</p>
              <p className="mt-1 text-xs text-zinc-600">{roleLabel(profile.role)}</p>
              <a
                className="focus-ring mt-3 inline-flex rounded-md border border-zinc-300 bg-white px-3 py-2 text-xs font-bold text-zinc-800"
                href={signOutPath()}
              >
                Cerrar sesión
              </a>
            </div>
          </div>
        </aside>

        <section className="min-w-0 flex-1">
          <div className="mx-auto flex w-full max-w-7xl flex-col gap-6 px-4 py-5 sm:px-6 lg:px-8 lg:py-8">
            {children}
          </div>
        </section>
      </div>
    </main>
  );
}
