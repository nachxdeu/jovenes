import Link from "next/link";
import { removeRecord } from "../app/actions";
import { getCoordinator } from "../lib/catalog";
import { canManage } from "../lib/session";
import type {
  Activity,
  ArgumentCard,
  CoordinatorSlug,
  CoordinatorTask,
  InternalDocument,
  InternalEvent,
  MeetingMinute,
  UserProfile,
} from "../lib/types";
import { formatDate, splitList } from "../lib/utils";

type RecordTable =
  | "documents"
  | "minutes"
  | "events"
  | "activities"
  | "tasks"
  | "argument_cards";

export function PageHeader({
  eyebrow,
  title,
  children,
}: {
  eyebrow: string;
  title: string;
  children?: React.ReactNode;
}) {
  return (
    <header className="political-band rounded-lg border border-[var(--line)] px-5 py-6 sm:px-6">
      <p className="text-xs font-black uppercase tracking-wide text-[var(--primary-dark)]">
        {eyebrow}
      </p>
      <div className="mt-2 flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
        <h1 className="max-w-3xl text-3xl font-black leading-tight text-[var(--ink)] sm:text-4xl">
          {title}
        </h1>
        {children}
      </div>
    </header>
  );
}

export function SectionTitle({
  title,
  action,
}: {
  title: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-3">
      <h2 className="text-lg font-black text-[var(--ink)]">{title}</h2>
      {action}
    </div>
  );
}

export function Panel({
  children,
  className = "",
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section
      className={`rounded-lg border border-[var(--line)] bg-white p-4 shadow-sm shadow-zinc-200/50 sm:p-5 ${className}`}
    >
      {children}
    </section>
  );
}

export function CoordinatorBadge({
  slug,
}: {
  slug: CoordinatorSlug | "general";
}) {
  if (slug === "general") {
    return (
      <span className="inline-flex items-center rounded-full bg-zinc-900 px-2.5 py-1 text-xs font-bold text-white">
        General
      </span>
    );
  }
  const coordinator = getCoordinator(slug);
  return (
    <span
      className="inline-flex items-center rounded-full px-2.5 py-1 text-xs font-bold text-white"
      style={{ backgroundColor: coordinator?.accent ?? "#0f8f43" }}
    >
      {coordinator?.name ?? slug}
    </span>
  );
}

export function Tags({ value }: { value: string }) {
  const tags = splitList(value);
  if (!tags.length) return null;
  return (
    <div className="flex flex-wrap gap-1.5">
      {tags.map((tag) => (
        <span
          className="rounded-full bg-zinc-100 px-2 py-1 text-xs font-semibold text-zinc-700"
          key={tag}
        >
          {tag}
        </span>
      ))}
    </div>
  );
}

export function EmptyState({ children }: { children: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-dashed border-zinc-300 bg-zinc-50 px-4 py-8 text-center text-sm font-medium text-zinc-600">
      {children}
    </div>
  );
}

export function DocumentCard({
  document,
  profile,
}: {
  document: InternalDocument;
  profile: UserProfile;
}) {
  return (
    <article className="rounded-lg border border-[var(--line)] bg-white p-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0 space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <CoordinatorBadge slug={document.coordinatorSlug} />
            <span className="rounded-full bg-zinc-100 px-2.5 py-1 text-xs font-bold text-zinc-700">
              {document.type}
            </span>
            <span className="text-xs font-semibold text-zinc-500">
              {formatDate(document.uploadedAt)}
            </span>
          </div>
          <h3 className="text-base font-black text-[var(--ink)]">
            {document.title}
          </h3>
          <p className="text-sm leading-6 text-zinc-600">{document.summary}</p>
          <Tags value={document.tags} />
        </div>
        <RecordActions
          attachmentName={document.attachmentName}
          attachmentUrl={document.attachmentUrl}
          canDelete={canManage(profile, document.coordinatorSlug)}
          id={document.id}
          table="documents"
        />
      </div>
      <p className="mt-3 text-xs font-semibold text-zinc-500">
        Responsable: {document.owner}
      </p>
    </article>
  );
}

export function MinuteCard({
  minute,
  profile,
}: {
  minute: MeetingMinute;
  profile: UserProfile;
}) {
  return (
    <article className="rounded-lg border border-[var(--line)] bg-white p-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0 space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <CoordinatorBadge slug={minute.spaceSlug} />
            <span className="text-xs font-semibold text-zinc-500">
              {formatDate(minute.meetingDate)}
            </span>
          </div>
          <h3 className="text-base font-black text-[var(--ink)]">
            {minute.title}
          </h3>
          <p className="text-sm leading-6 text-zinc-600">
            <strong>Acuerdos:</strong> {minute.agreements || "Sin acuerdos registrados"}
          </p>
          {minute.assignedTasks ? (
            <p className="text-sm leading-6 text-zinc-600">
              <strong>Tareas:</strong> {minute.assignedTasks}
            </p>
          ) : null}
        </div>
        <RecordActions
          attachmentUrl={minute.attachmentUrl}
          canDelete={canManage(profile, minute.spaceSlug)}
          id={minute.id}
          table="minutes"
        />
      </div>
    </article>
  );
}

export function EventCard({
  event,
  profile,
}: {
  event: InternalEvent;
  profile: UserProfile;
}) {
  return (
    <article className="rounded-lg border border-[var(--line)] bg-white p-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0 space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <CoordinatorBadge slug={event.coordinatorSlug} />
            <span className="rounded-full bg-zinc-100 px-2.5 py-1 text-xs font-bold text-zinc-700">
              {event.type}
            </span>
            <span className="text-xs font-semibold text-zinc-500">
              {formatDate(event.eventDate)} {event.eventTime}
            </span>
          </div>
          <h3 className="text-base font-black text-[var(--ink)]">
            {event.title}
          </h3>
          <p className="text-sm font-semibold text-zinc-700">{event.place}</p>
          <p className="text-sm leading-6 text-zinc-600">{event.description}</p>
        </div>
        <RecordActions
          attachmentUrl={event.resourceUrl}
          canDelete={canManage(profile, event.coordinatorSlug)}
          id={event.id}
          table="events"
        />
      </div>
      {event.people ? (
        <p className="mt-3 text-xs font-semibold text-zinc-500">
          Responsables: {event.people}
        </p>
      ) : null}
    </article>
  );
}

export function ActivityCard({
  activity,
  profile,
}: {
  activity: Activity;
  profile: UserProfile;
}) {
  const canDelete = activity.coordinatorSlugs.some((slug) =>
    canManage(profile, slug),
  );
  return (
    <article className="rounded-lg border border-[var(--line)] bg-white p-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0 space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            {activity.coordinatorSlugs.map((slug) => (
              <CoordinatorBadge key={slug} slug={slug} />
            ))}
            <span className="rounded-full bg-zinc-100 px-2.5 py-1 text-xs font-bold text-zinc-700">
              {activity.type}
            </span>
            <span className="text-xs font-semibold text-zinc-500">
              {formatDate(activity.activityDate)}
            </span>
          </div>
          <h3 className="text-base font-black text-[var(--ink)]">
            {activity.title}
          </h3>
          <p className="text-sm font-semibold text-zinc-700">{activity.place}</p>
          <p className="text-sm leading-6 text-zinc-600">{activity.description}</p>
          {activity.objective ? (
            <p className="text-sm leading-6 text-zinc-600">
              <strong>Objetivo:</strong> {activity.objective}
            </p>
          ) : null}
          {activity.evaluation ? (
            <p className="text-sm leading-6 text-zinc-600">
              <strong>Balance:</strong> {activity.evaluation}
            </p>
          ) : null}
          <Tags value={activity.tags} />
        </div>
        <RecordActions
          attachmentUrl={activity.links}
          canDelete={canDelete}
          id={activity.id}
          table="activities"
        />
      </div>
      {activity.campaign ? (
        <p className="mt-3 text-xs font-semibold text-zinc-500">
          Campaña: {activity.campaign}
        </p>
      ) : null}
    </article>
  );
}

export function ArgumentCardView({
  card,
  profile,
}: {
  card: ArgumentCard;
  profile: UserProfile;
}) {
  return (
    <article className="rounded-lg border border-[var(--line)] bg-white p-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0 space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <CoordinatorBadge slug={card.coordinatorSlug} />
            <span className="rounded-full bg-zinc-900 px-2.5 py-1 text-xs font-bold text-white">
              {card.topic}
            </span>
            <span className="rounded-full bg-zinc-100 px-2.5 py-1 text-xs font-bold text-zinc-700">
              {card.territory}
            </span>
            <span className="rounded-full bg-zinc-100 px-2.5 py-1 text-xs font-bold text-zinc-700">
              {card.type}
            </span>
          </div>
          <div>
            <h3 className="text-base font-black text-[var(--ink)]">
              {card.title}
            </h3>
            {card.summary ? (
              <p className="mt-1 text-sm leading-6 text-zinc-600">
                {card.summary}
              </p>
            ) : null}
          </div>
          <ArgumentBlock label="Mensajes clave" value={card.keyMessages} />
          <ArgumentBlock label="Datos útiles" value={card.dataPoints} />
          <ArgumentBlock label="Respuesta rápida" value={card.rebuttal} />
          <ArgumentBlock label="Fuentes" value={card.sources} />
          <Tags value={card.tags} />
        </div>
        <RecordActions
          canDelete={canManage(profile, card.coordinatorSlug)}
          id={card.id}
          table="argument_cards"
        />
      </div>
      <div className="mt-3 flex flex-wrap gap-3 text-xs font-semibold text-zinc-500">
        <span>Actualizada: {formatDate(card.updatedAt)}</span>
        {card.campaign ? <span>Campaña: {card.campaign}</span> : null}
      </div>
    </article>
  );
}

export function TaskList({
  tasks,
  profile,
}: {
  tasks: CoordinatorTask[];
  profile: UserProfile;
}) {
  if (!tasks.length) return <EmptyState>No hay tareas pendientes.</EmptyState>;
  return (
    <div className="divide-y divide-[var(--line)]">
      {tasks.map((task) => (
        <div className="flex items-start justify-between gap-3 py-3" key={task.id}>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <CoordinatorBadge slug={task.coordinatorSlug} />
              {task.dueDate ? (
                <span className="text-xs font-semibold text-zinc-500">
                  {formatDate(task.dueDate)}
                </span>
              ) : null}
            </div>
            <p className="mt-2 text-sm font-bold text-[var(--ink)]">{task.title}</p>
            {task.source ? (
              <p className="mt-1 text-xs font-semibold text-zinc-500">
                {task.source}
              </p>
            ) : null}
          </div>
          {canManage(profile, task.coordinatorSlug) ? (
            <DeleteControl id={task.id} table="tasks" />
          ) : null}
        </div>
      ))}
    </div>
  );
}

export function QuickLink({
  href,
  title,
  text,
  accent,
}: {
  href: string;
  title: string;
  text: string;
  accent: string;
}) {
  return (
    <Link
      className="focus-ring rounded-lg border border-[var(--line)] bg-white p-4 transition hover:-translate-y-0.5 hover:shadow-md"
      href={href}
    >
      <span
        className="mb-3 block h-1.5 w-14 rounded-full"
        style={{ backgroundColor: accent }}
      />
      <h3 className="font-black">{title}</h3>
      <p className="mt-2 text-sm leading-6 text-zinc-600">{text}</p>
    </Link>
  );
}

function RecordActions({
  attachmentName,
  attachmentUrl,
  canDelete,
  id,
  table,
}: {
  attachmentName?: string;
  attachmentUrl?: string;
  canDelete: boolean;
  id: string;
  table: RecordTable;
}) {
  const hasAttachment = Boolean(attachmentUrl);
  return (
    <div className="flex shrink-0 flex-wrap gap-2 sm:justify-end">
      {hasAttachment ? (
        <a
          className="focus-ring inline-flex rounded-md border border-zinc-300 px-3 py-2 text-xs font-black text-zinc-800 hover:bg-zinc-50"
          href={attachmentUrl}
          rel="noreferrer"
          target={attachmentUrl?.startsWith("http") ? "_blank" : undefined}
        >
          {attachmentName || "Abrir"}
        </a>
      ) : null}
      {canDelete ? <DeleteControl id={id} table={table} /> : null}
    </div>
  );
}

function ArgumentBlock({ label, value }: { label: string; value: string }) {
  const items = splitList(value);
  if (!value.trim()) return null;
  return (
    <div className="rounded-md bg-zinc-50 p-3">
      <p className="text-xs font-black uppercase text-zinc-500">{label}</p>
      {items.length > 1 ? (
        <ul className="mt-2 grid gap-1.5 text-sm leading-6 text-zinc-700">
          {items.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      ) : (
        <p className="mt-2 text-sm leading-6 text-zinc-700">{value}</p>
      )}
    </div>
  );
}

function DeleteControl({ id, table }: { id: string; table: RecordTable }) {
  return (
    <form action={removeRecord}>
      <input name="id" type="hidden" value={id} />
      <input name="table" type="hidden" value={table} />
      <button
        className="focus-ring rounded-md border border-red-200 px-3 py-2 text-xs font-black text-red-700 hover:bg-red-50"
        type="submit"
      >
        Borrar
      </button>
    </form>
  );
}
