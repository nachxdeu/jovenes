import { sql } from "drizzle-orm";
import { integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const coordinators = sqliteTable("coordinators", {
  slug: text("slug").primaryKey(),
  name: text("name").notNull(),
  accent: text("accent").notNull(),
  description: text("description").notNull().default(""),
});

export const users = sqliteTable("users", {
  email: text("email").primaryKey(),
  name: text("name").notNull(),
  role: text("role", { enum: ["admin", "coordinator", "internal"] })
    .notNull()
    .default("internal"),
  coordinatorSlug: text("coordinator_slug").references(() => coordinators.slug),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const documents = sqliteTable("documents", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  summary: text("summary").notNull().default(""),
  coordinatorSlug: text("coordinator_slug")
    .notNull()
    .references(() => coordinators.slug),
  type: text("type").notNull(),
  uploadedAt: text("uploaded_at").notNull(),
  owner: text("owner").notNull(),
  attachmentName: text("attachment_name").notNull().default(""),
  attachmentUrl: text("attachment_url").notNull().default(""),
  tags: text("tags").notNull().default(""),
  createdByEmail: text("created_by_email").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const minutes = sqliteTable("minutes", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  meetingDate: text("meeting_date").notNull(),
  spaceSlug: text("space_slug").notNull(),
  attendees: text("attendees").notNull().default(""),
  agenda: text("agenda").notNull().default(""),
  agreements: text("agreements").notNull().default(""),
  assignedTasks: text("assigned_tasks").notNull().default(""),
  nextMeeting: text("next_meeting").notNull().default(""),
  attachmentUrl: text("attachment_url").notNull().default(""),
  body: text("body").notNull().default(""),
  createdByEmail: text("created_by_email").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const events = sqliteTable("events", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  eventDate: text("event_date").notNull(),
  eventTime: text("event_time").notNull().default(""),
  place: text("place").notNull().default(""),
  description: text("description").notNull().default(""),
  coordinatorSlug: text("coordinator_slug")
    .notNull()
    .references(() => coordinators.slug),
  type: text("type").notNull(),
  people: text("people").notNull().default(""),
  resourceUrl: text("resource_url").notNull().default(""),
  createdByEmail: text("created_by_email").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const activities = sqliteTable("activities", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  activityDate: text("activity_date").notNull(),
  year: integer("year").notNull(),
  place: text("place").notNull().default(""),
  description: text("description").notNull().default(""),
  coordinatorSlugs: text("coordinator_slugs").notNull().default("[]"),
  objective: text("objective").notNull().default(""),
  materials: text("materials").notNull().default(""),
  links: text("links").notNull().default(""),
  evaluation: text("evaluation").notNull().default(""),
  tags: text("tags").notNull().default(""),
  type: text("type").notNull().default("otro"),
  campaign: text("campaign").notNull().default(""),
  createdByEmail: text("created_by_email").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const tasks = sqliteTable("tasks", {
  id: text("id").primaryKey(),
  coordinatorSlug: text("coordinator_slug")
    .notNull()
    .references(() => coordinators.slug),
  title: text("title").notNull(),
  status: text("status", { enum: ["pending", "done"] })
    .notNull()
    .default("pending"),
  dueDate: text("due_date").notNull().default(""),
  source: text("source").notNull().default(""),
  createdByEmail: text("created_by_email").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const argumentCards = sqliteTable("argument_cards", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  summary: text("summary").notNull().default(""),
  topic: text("topic").notNull(),
  territory: text("territory").notNull().default("General"),
  type: text("type").notNull().default("ficha"),
  coordinatorSlug: text("coordinator_slug")
    .notNull()
    .references(() => coordinators.slug),
  campaign: text("campaign").notNull().default(""),
  keyMessages: text("key_messages").notNull().default(""),
  dataPoints: text("data_points").notNull().default(""),
  rebuttal: text("rebuttal").notNull().default(""),
  sources: text("sources").notNull().default(""),
  tags: text("tags").notNull().default(""),
  updatedAt: text("updated_at").notNull(),
  createdByEmail: text("created_by_email").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});
